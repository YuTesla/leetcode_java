package leetcode.utils;

public class Sort {
    public void bubbleSort(int[] arr) {
        if (arr == null || arr.length < 2) return;
        for (int e = arr.length - 1; e > 0; e--) {
            for (int i = 0; i < e; i++) {
                if (arr[i] > arr[i + 1]) {
                    swap(arr, i, i + 1);
                }
            }
        }

    }


    public void selectionSort(int[] arr) {
        if (arr == null || arr.length < 2) return;
        for (int i = 0; i < arr.length-1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < arr.length; j++) {
                minIndex = arr[minIndex] > arr[j] ? j : minIndex;
            }
            if(i!=minIndex)swap(arr, i, minIndex);
        }

    }


    public void insertionSort(int[] arr) {
        if (arr == null || arr.length < 2) return;
        for (int i = 1; i < arr.length; i++) {
            for (int j = i - 1; j >= 0 && arr[j] > arr[j + 1]; j--) {
                swap(arr, j, j + 1);
            }
        }
    }


    public void mergeSort(int[] arr) {
        if (arr == null || arr.length < 2) return;
        mergeSort(arr, 0, arr.length - 1);
    }

    public void mergeSort(int[] arr, int l, int r) {
        if (l == r) return;
        int mid = l + ((r - l) >> 1);
        mergeSort(arr, l, mid);
        mergeSort(arr, mid + 1, r);
        merge(arr, l, mid, r);
    }

    public void merge(int[] arr, int l, int mid, int r) {
        int[] help = new int[r - l + 1];
        int i = 0;
        int p1 = l;
        int p2 = mid + 1;
        while (p1 <= mid && p2 <= r) {
            help[i++] = arr[p1] < arr[p2] ? arr[p1++] : arr[p2++];
        }
        while (p1 <= mid) {
            help[i++] = arr[p1++];
        }
        while (p2 <= r) {
            help[i++] = arr[p2++];
        }
        for (i = 0; i < help.length; i++) {
            arr[l + i] = help[i];
        }
    }


    public void quickSort(int[] arr){
        if(arr==null||arr.length<2)return;
        quickSort(arr,0,arr.length-1);
    }

    public void quickSort(int[] arr,int l,int r){
        if(l<r){
            swap(arr,r,l+(int)(Math.random()*(r-l+1)));
            int[] p=partition(arr,l,r);
            quickSort(arr,l,p[0]-1);
            quickSort(arr,p[1]+1,r);
        }
    }

    public int[] partition(int[] arr,int l,int r){
        int num=arr[r];
        int left=l-1;
        int right=r+1;
        while(l<right){
            if(arr[l]>num){
                swap(arr,l,--right);
            }else if(arr[l]<num){
                swap(arr,++left,l++);
            }else{
                l++;
            }
        }
        return new int[]{left+1,right-1};
    }


    public void swap(int[] arr, int i, int j) {
//        arr[i] = arr[i] ^ arr[j];
//        arr[j] = arr[i] ^ arr[j];
//        arr[i] = arr[i] ^ arr[j];
        int tmp=arr[i];
        arr[i]=arr[j];
        arr[j]=tmp;
    }


    public static int[] generateRandomArray(int maxSize, int maxValue) {
        int[] arr = new int[(int) ((maxSize + 1) * Math.random())];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) ((maxValue + 1) * Math.random());
        }
        return arr;
    }

    public static void main(String[] args) {
        Sort s = new Sort();
        int[] arr = generateRandomArray(40, 9);
        for (int num : arr) {
            System.out.print(num);
        }
        s.quickSort(arr);
        System.out.println();
        for (int num : arr) {
            System.out.print(num);
        }
    }
}

